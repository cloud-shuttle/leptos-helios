/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const main: () => void;
export const greet: (a: number, b: number, c: number) => void;
export const process_data: (a: number, b: number, c: number) => void;
export const create_simple_chart: (a: number) => void;
export const test_webgpu_support: (a: number) => void;
export const create_chart_data: (a: number, b: number, c: number, d: number) => void;
export const process_chart_data: (a: number, b: number, c: number) => void;
export const __wbindgen_export_0: (a: number) => void;
export const __wbindgen_export_1: (a: number, b: number, c: number) => void;
export const __wbindgen_export_2: (a: number, b: number) => number;
export const __wbindgen_export_3: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_add_to_stack_pointer: (a: number) => number;
export const __wbindgen_start: () => void;
